export interface ReservationData {
  date: string;
  time: string;
  guests: string;
  name: string;
  email: string;
  phone: string;
}