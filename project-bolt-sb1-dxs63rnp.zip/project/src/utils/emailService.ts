export const sendReservationEmail = async (formData: {
  date: string;
  time: string;
  guests: string;
  name: string;
  email: string;
  phone: string;
}) => {
  try {
    const response = await fetch('https://api.emailjs.com/api/v1.0/email/send', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        service_id: 'default_service',
        template_id: 'template_reservation',
        user_id: 'YOUR_USER_ID', // You'll need to replace this with your EmailJS user ID
        template_params: {
          to_email: 'dveritas@hotmail.fr',
          from_name: formData.name,
          guest_email: formData.email,
          guest_phone: formData.phone,
          reservation_date: formData.date,
          reservation_time: formData.time,
          guests: formData.guests,
        },
      }),
    });
    
    return response.ok;
  } catch (error) {
    console.error('Error sending email:', error);
    return false;
  }
};